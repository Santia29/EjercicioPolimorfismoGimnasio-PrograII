
package integradorpolimorfismogimnasio;

import java.time.LocalDate;


public class PersonalTrainer extends Entrenador{
    
    private double sueldoMinimo;
    private int numeroClientes;
    private double montoPorClientes;

    public PersonalTrainer(int legajo, String nombre, String apellido, 
            LocalDate fechaIngreso,double sueldoMinimo, int numeroClientes, double montoPorClientes) {
        super(legajo, nombre, apellido, fechaIngreso);
        this.sueldoMinimo = sueldoMinimo;
        this.numeroClientes = numeroClientes;
        this.montoPorClientes = montoPorClientes;
    }

    @Override
    public double calcularSueldo() {
        if(calcularSueldoPorCliente() < this.sueldoMinimo){
        return sueldoMinimo;
        }
        return calcularSueldo();
    }
        
    public double calcularSueldoPorCliente(){
        return this.numeroClientes * this.montoPorClientes;
    }
}
