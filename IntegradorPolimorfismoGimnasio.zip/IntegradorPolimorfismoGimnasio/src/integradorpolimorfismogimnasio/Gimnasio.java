
package integradorpolimorfismogimnasio;

import java.util.ArrayList;
import java.util.List;

public class Gimnasio {
    
    private String nombre;
    private final List<Entrenador> entrenadores;
    
    
    public Gimnasio(String nombre) {
        this.nombre = nombre;
        entrenadores = new ArrayList<>();
    }
    
    public void mostrarSueldos(){
        System.out.println("Lista de sueldos del gimnasio " + nombre);
        for(Entrenador e : entrenadores){
            System.out.println(e.getNombre() + " " + e.getApellido() + ": " + e.calcularSueldo());
            
        }
        
    }
    
    public void agregarEntrenador(Entrenador e){
        if(e != null){
            
            entrenadores.add(e);
            
        }
    }
    
    
}
