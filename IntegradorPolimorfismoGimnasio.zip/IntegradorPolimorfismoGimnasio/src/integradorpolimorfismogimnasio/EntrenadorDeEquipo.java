
package integradorpolimorfismogimnasio;

import java.time.LocalDate;
import java.time.Period;


public class EntrenadorDeEquipo extends Entrenador{
    
    private static final double ESC_1 = 0.04;
    private static final double ESC_2 = 0.12;
    private static final int ANTIGUEDAD_1 =  3;
    private static final int ANTIGUEDAD_2 =  6;
    private double sueldoFijo;
    
    public EntrenadorDeEquipo(double sueldoFijo, int legajo, String nombre, String apellido, LocalDate fechaIngreso) {
        super(legajo, nombre, apellido, fechaIngreso);
        this.sueldoFijo = sueldoFijo;
    }
    
    @Override
    public double calcularSueldo(){
        int anioAntiguedad = Period.between(fechaIngreso, LocalDate.now()).getYears();
        
        if(anioAntiguedad < ANTIGUEDAD_1){
            return sueldoFijo;
        }
            else if(anioAntiguedad >= ANTIGUEDAD_1 && anioAntiguedad <= ANTIGUEDAD_2){
                return sueldoFijo + sueldoFijo * ESC_1 ;
            }
            else{
                return sueldoFijo + sueldoFijo * ESC_2 ;
            }
    }
    
   /* public double getSueldo(){
        return calcularSueldo();
    }*/
    //RETOMAR CLASE 14 2:03:00
    
}
