
package integradorpolimorfismogimnasio;

import java.time.LocalDate;


public class IntegradorPolimorfismoGimnasio {

    public static void main(String[] args) {
       
        Gimnasio gim = new Gimnasio("bronti gym"); 
         
        cargarGimnasio(gim);
        
        gim.mostrarSueldos();
        
        
        
    }
    
    public static void cargarGimnasio(Gimnasio g){
        
        g.agregarEntrenador(new EntrenadorDeEquipo(100, 12340, "Brandi", "wellington", LocalDate.MIN));
        g.agregarEntrenador(new PersonalTrainer(1425,));
    }
    //RETOMAR CLASE 14 2:27:00
}
