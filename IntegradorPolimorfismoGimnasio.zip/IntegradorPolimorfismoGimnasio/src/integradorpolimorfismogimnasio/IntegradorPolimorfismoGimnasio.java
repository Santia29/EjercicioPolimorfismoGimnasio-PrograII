
package integradorpolimorfismogimnasio;

import java.time.LocalDate;
import java.time.Month;


public class IntegradorPolimorfismoGimnasio {

    public static void main(String[] args) {
       
        Gimnasio gim = new Gimnasio("bronti gym"); 
         
        cargarGimnasio(gim);
        
        gim.mostrarSueldos();
        
        PersonalTrainer mayorCliente = gim.entrenadorMasClientes();
        
        if(mayorCliente != null){
            System.out.println(mayorCliente.getNombre() + mayorCliente.getApellido() + ": " +mayorCliente.getClientes());
        }
        
        
    }
    
    public static void cargarGimnasio(Gimnasio g){
        
        g.agregarEntrenador(new EntrenadorDeEquipo(100, 12340, "Brandi", "wellington", LocalDate.of(2016, 7, 20)));
        g.agregarEntrenador(new PersonalTrainer(1425,"roman","aurelio", LocalDate.of(2020, Month.MARCH, 21),10000.,11,3000.));
        g.agregarEntrenador(new PersonalTrainer(1425,"ramon","catelio", LocalDate.of(2020, Month.MARCH, 21),10000.,13,3000.));
    }
}
